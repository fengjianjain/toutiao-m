import axios from 'axios'

const request = axios.create({
  baseURL: 'http://toutiao-app.itheima.net/' // 基础路径
})
// 请求拦截器
// 相应拦截器
export default request
